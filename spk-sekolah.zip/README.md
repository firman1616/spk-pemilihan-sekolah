# spk-sekolah
Sistem Pendukung Keputusan untuk Memilih Sekolah SMA dengan Metode AHP dan SAW
