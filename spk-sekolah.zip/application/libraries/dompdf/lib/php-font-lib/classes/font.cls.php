<?php

// To let external includes work after renaming
require_once dirname(__FILE__) . "/Font.php";
